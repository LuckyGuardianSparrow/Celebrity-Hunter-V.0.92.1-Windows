# ============================================================
# SERVIDOR LOCAL PARA WINDOWS
# ============================================================
# Salve como: game/zz_liberar_tempos_windows.rpy
# ============================================================

init 999 python:

    # --------------------------------------------------------
    # FUNCOES GERAIS
    # --------------------------------------------------------

    def dm_numero_inteiro(dm_valor, dm_padrao=0):
        try:
            return int(dm_valor)
        except Exception:
            return dm_padrao


    def dm_definir_se_ausente(dm_nome, dm_valor):
        if not hasattr(store, dm_nome):
            setattr(store, dm_nome, dm_valor)


    def dm_retorna_true(self, *args, **kwargs):
        return True


    # --------------------------------------------------------
    # TEMPORIZADORES
    # --------------------------------------------------------

    def dm_liberar_todos_tempos_windows():
        if renpy.android:
            return

        for dm_nome in (
            "mtempo",
            "mttempo",
            "tbtempo",
            "tltempo",
            "ftempo",
            "etempo",
            "ntempo",
            "stempo",
            "checatempo",
        ):
            setattr(store, dm_nome, True)


    # --------------------------------------------------------
    # SLOTS LOCAIS
    # --------------------------------------------------------

    def dm_pega_salvado(self, *args, **kwargs):
        store.salvado = True
        return True


    def dm_salva_jogo_slots(self, *args, **kwargs):
        store.salvado = True
        persistent.dm_slots_credito = dm_numero_inteiro(
            getattr(store, "credito", 0)
        )
        persistent.dm_slots_credito_total = dm_numero_inteiro(
            getattr(store, "credito_total", 0)
        )
        renpy.save_persistent()
        return True


    def dm_pega_credito(self, *args, **kwargs):
        store.credito = max(
            0,
            dm_numero_inteiro(getattr(store, "credito", 0))
        )
        return store.credito


    def dm_pega_credito_total(self, *args, **kwargs):
        store.credito_total = max(
            0,
            dm_numero_inteiro(getattr(store, "credito_total", 0))
        )
        return store.credito_total


    def dm_add_credito(self, quantidade=0, *args, **kwargs):
        dm_quantidade = max(0, dm_numero_inteiro(quantidade))
        store.credito = max(
            0,
            dm_numero_inteiro(getattr(store, "credito", 0))
            + dm_quantidade
        )
        store.credito_total = max(
            0,
            dm_numero_inteiro(getattr(store, "credito_total", 0))
            + dm_quantidade
        )
        dm_salva_jogo_slots(self)
        return store.credito


    def dm_usa_credito(self, quantidade=0, *args, **kwargs):
        dm_quantidade = max(0, dm_numero_inteiro(quantidade))
        store.credito = max(
            0,
            dm_numero_inteiro(getattr(store, "credito", 0))
            - dm_quantidade
        )
        dm_salva_jogo_slots(self)
        return store.credito


    def dm_troca_credito(self, *args, **kwargs):
        if args:
            dm_quantidade = dm_numero_inteiro(args[0])
            if dm_quantidade > 0:
                return dm_add_credito(self, dm_quantidade)
        return dm_pega_credito(self)


    def dm_restaurar_slots_windows():
        if renpy.android:
            return

        dm_definir_se_ausente("credito", 0)
        dm_definir_se_ausente("credito_total", 0)
        dm_definir_se_ausente("salvado", True)

        store.credito = max(
            0,
            dm_numero_inteiro(getattr(store, "credito", 0)),
            dm_numero_inteiro(
                getattr(persistent, "dm_slots_credito", 0)
            ),
        )
        store.credito_total = max(
            0,
            dm_numero_inteiro(getattr(store, "credito_total", 0)),
            dm_numero_inteiro(
                getattr(persistent, "dm_slots_credito_total", 0)
            ),
        )
        store.salvado = True


    # --------------------------------------------------------
    # COMPRAS LOCAIS NO WINDOWS
    # --------------------------------------------------------

    def dm_comprar_item_windows(item, preco):
        if renpy.android:
            return False

        item = str(item).strip().lower()
        preco = dm_numero_inteiro(preco, 0)
        saldo = dm_numero_inteiro(getattr(store, "cash", 0), 0)

        if preco <= 0:
            return False

        if item == "blazer":
            if getattr(store, "roupa_blazer", False):
                return True
            if saldo < preco:
                return False
            store.cash = saldo - preco
            store.roupa_blazer = True
            return True

        if item == "blacktie":
            if getattr(store, "roupa_blacktie", False):
                return True
            if saldo < preco:
                return False
            store.cash = saldo - preco
            store.roupa_blacktie = True
            return True

        if item == "casa":
            if getattr(store, "casa", False):
                store.casa_comprada = True
                return True
            if saldo < preco:
                return False
            store.cash = saldo - preco
            store.casa = True
            store.casa_comprada = True
            return True

        return False


    def dm_compra_blazer(self, *args, **kwargs):
        return dm_comprar_item_windows("blazer", 250)


    def dm_compra_blacktie(self, *args, **kwargs):
        return dm_comprar_item_windows("blacktie", 1000)


    def dm_compra_casa(self, *args, **kwargs):
        return dm_comprar_item_windows("casa", 2000)


    def dm_pega_blazer(self, *args, **kwargs):
        return bool(getattr(store, "roupa_blazer", False))


    def dm_pega_blacktie(self, *args, **kwargs):
        return bool(getattr(store, "roupa_blacktie", False))


    def dm_pega_casa(self, *args, **kwargs):
        return bool(getattr(store, "casa", False))


    def dm_pega_cash(self, *args, **kwargs):
        store.cash = max(
            0,
            dm_numero_inteiro(getattr(store, "cash", 0))
        )
        return store.cash


    # --------------------------------------------------------
    # INSTALACAO NO ADAPTADOR OFFLINE
    # --------------------------------------------------------

    def dm_instalar_servidor_local_windows():
        if renpy.android:
            return

        dm_atividade = getattr(store, "PythonSDLActivity", None)
        if dm_atividade is None:
            return

        dm_classe = dm_atividade.__class__

        for dm_nome in (
            "checkMtempoNext", "setMtempoNext", "avancaMasTempo",
            "checkMTtempoNext", "setMTtempoNext", "avancaMTTempo",
            "checkTBtempoNext", "setTBtempoNext", "avancaTBTempo",
            "checkTLtempoNext", "setTLtempoNext", "avancaTLTempo",
            "checkFtempoNext", "setFtempoNext", "avancaFTempo",
            "checkEPtempoNext", "setEPtempoNext", "avancaEPTempo",
            "checkNtempoNext", "setNtempoNext", "avancaNTempo",
            "checkStempoNext", "setStempoNext", "avancaSTempo",
            "checkMasTempoNext", "setMasTempoNext",
            "checkTrabalhoTempoNext", "setTrabalhoTempoNext",
        ):
            setattr(dm_classe, dm_nome, dm_retorna_true)

        dm_classe.salvaJogo = dm_salva_jogo_slots
        dm_classe.pegaSalvado = dm_pega_salvado
        dm_classe.pegaCredito = dm_pega_credito
        dm_classe.pegaCreditoTotal = dm_pega_credito_total
        dm_classe.addCredito = dm_add_credito
        dm_classe.ganhaCredito = dm_add_credito
        dm_classe.usaCredito = dm_usa_credito
        dm_classe.trocaCredito = dm_troca_credito

        dm_classe.pegaCash = dm_pega_cash
        dm_classe.compraBlazer = dm_compra_blazer
        dm_classe.compraBlacktie = dm_compra_blacktie
        dm_classe.compraCasa = dm_compra_casa
        dm_classe.pegaBlazer = dm_pega_blazer
        dm_classe.pegaBlacktie = dm_pega_blacktie
        dm_classe.pegaCasa = dm_pega_casa


    def dm_atualizar_servidor_local_windows():
        if renpy.android:
            return
        dm_instalar_servidor_local_windows()
        dm_liberar_todos_tempos_windows()
        dm_restaurar_slots_windows()


    dm_atualizar_servidor_local_windows()

    if dm_atualizar_servidor_local_windows not in config.overlay_functions:
        config.overlay_functions.append(
            dm_atualizar_servidor_local_windows
        )


# ============================================================
# SLOTS: VITORIA GARANTIDA
# ============================================================

label slots_conta:

    $ aposta = max(0, int(aposta or 0))
    $ credito = max(0, int(credito or 0))
    $ credito_total = max(0, int(credito_total or 0))

    $ slot_result1 = "sete"
    $ slot_result2 = "sete"
    $ slot_result3 = "sete"
    $ slots_ganhou = True
    $ ganhos = aposta * 5

    if renpy.android:

        python:
            PythonSDLActivity.addCredito(ganhos, aposta)
            credito = PythonSDLActivity.pegaCredito()
            credito_total = PythonSDLActivity.pegaCreditoTotal()

    else:

        $ credito += ganhos
        $ credito -= aposta
        $ credito_total += ganhos
        $ credito = max(0, credito)

        python:
            persistent.dm_slots_credito = credito
            persistent.dm_slots_credito_total = credito_total
            salvado = True
            renpy.save_persistent()

    return
